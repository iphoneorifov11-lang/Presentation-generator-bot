import os, json
from pydantic import BaseModel, Field
from typing import List, Optional
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
if not OPENAI_API_KEY:
    raise RuntimeError("OPENAI_API_KEY topilmadi (.env ni tekshiring)")

client = OpenAI(api_key=OPENAI_API_KEY)

SYSTEM_PROMPT = """Sen tajribali prezenter va kontent yaratuvchisan.
Foydalanuvchi bergan mavzu va ism-familiyadan foydalanib, o'zbek tilida,
8-12 slayddan iborat ta'sirchan prezentatsiya tuz. Faqat JSON qaytar (hech qanday izohsiz).
Schema:
{
  "title": "string",
  "subtitle": "string",
  "author_name": "string",
  "slides": [
    {"title":"string","bullets":["..."],"speaker_notes":"string","image_idea":"string"}
  ]
}
Talablar:
- Har bir slaydda 3-5 lo'nda bullet bo'lsin.
- Speaker_notes 1-3 gapdan iborat bo'lsin, og'zaki tushuntirishga mos.
- Auditoriya va ohangga mos, insondek, tabiiy tilda.
"""

class Slide(BaseModel):
    title: str
    bullets: List[str] = Field(default_factory=list)
    speaker_notes: Optional[str] = ""
    image_idea: Optional[str] = ""

class Deck(BaseModel):
    title: str
    subtitle: str = ""
    author_name: str
    slides: List[Slide]

def build_deck_from_llm(topic: str, author_name: str, audience: str = "", tone: str = "tabiiy, insondek") -> Deck:
    user_prompt = f"""
topic: "{topic}"
author_name: "{author_name}"
audience: "{audience}"
tone: "{tone}"
"""
    resp = client.chat.completions.create(
        model=OPENAI_MODEL,
        temperature=0.7,
        messages=[
            {"role":"system","content": SYSTEM_PROMPT},
            {"role":"user","content": user_prompt}
        ],
        response_format={"type":"json_object"}
    )
    content = resp.choices[0].message.content
    data = json.loads(content)
    return Deck(**data)

from pptx import Presentation
from pptx.util import Pt
from pptx.enum.text import PP_PARAGRAPH_ALIGNMENT
import io
from .model import Deck

def deck_to_pptx_bytes(deck: Deck) -> bytes:
    prs = Presentation()
    # Title slide
    title_layout = prs.slide_layouts[0]
    slide = prs.slides.add_slide(title_layout)
    slide.shapes.title.text = deck.title
    slide.placeholders[1].text = f"{deck.subtitle}\n{deck.author_name}"

    # Content slides
    for s in deck.slides:
        layout = prs.slide_layouts[1]  # Title and Content
        sl = prs.slides.add_slide(layout)
        sl.shapes.title.text = s.title

        body = sl.placeholders[1].text_frame
        body.clear()

        for i, b in enumerate(s.bullets):
            p = body.add_paragraph() if i > 0 else body.paragraphs[0]
            p.text = b
            p.level = 0
            p.font.size = Pt(20)

        if s.speaker_notes:
            notes = sl.notes_slide.notes_text_frame
            notes.text = s.speaker_notes

    bio = io.BytesIO()
    prs.save(bio)
    bio.seek(0)
    return bio.read()

import os, io, json
from aiogram import Bot, Dispatcher, types
from aiogram.utils import executor
from aiogram.types import InputFile
from dotenv import load_dotenv

from app.model import build_deck_from_llm, Deck
from app.presentation import deck_to_pptx_bytes

# Load .env
load_dotenv()
TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")
if not TELEGRAM_TOKEN:
    raise RuntimeError("TELEGRAM_TOKEN topilmadi (.env ni tekshiring)")

bot = Bot(token=TELEGRAM_TOKEN)
dp = Dispatcher(bot)

# Oddiy holat saqlovchi (MVP)
USER_STATE = {}  # chat_id -> {"step": ..., "topic": ..., "name": ...}

@dp.message_handler(commands=['start','help'])
async def start(msg: types.Message):
    await msg.answer("Salom! Men mavzu va ism-familya berilsa, siz nomingizdan ta'sirchan prezentatsiya tayyorlayman.\n"
                     "Boshlash uchun /new deb yozing.")

@dp.message_handler(commands=['new'])
async def new_flow(msg: types.Message):
    USER_STATE[msg.chat.id] = {"step": "ask_topic"}
    await msg.answer("Mavzuni yozing (masalan: 'Immunitet va shamollash').")

@dp.message_handler()
async def all_msgs(msg: types.Message):
    st = USER_STATE.get(msg.chat.id)
    if not st:
        await msg.answer("Iltimos /new deb yozing va bosqichma-bosqich ketamiz.")
        return

    if st["step"] == "ask_topic":
        st["topic"] = msg.text.strip()
        st["step"] = "ask_name"
        await msg.answer("Zo'r! Endi muallifning ismi-familyasini yozing (masalan: 'Orifov Ramziddin').")
        return

    if st["step"] == "ask_name":
        st["name"] = msg.text.strip()
        st["step"] = "generating"
        await msg.answer("Kontent pishiryapman 🔥 Bir zumdan fayl tayyor bo‘ladi...")
        try:
            deck: Deck = build_deck_from_llm(
                topic=st["topic"],
                author_name=st["name"],
                audience="1-kurs talabalari",
                tone="iliq, tushunarli, ilmiy soddalashtirilgan"
            )
        except Exception as e:
            await msg.answer("Kechirasiz, kontentni olishda muammo bo‘ldi. Yana /new qilib urining.\n"
                             f"Diag: {type(e).__name__}")
            USER_STATE.pop(msg.chat.id, None)
            return

        pptx_bytes = deck_to_pptx_bytes(deck)
        safe_title = deck.title[:40].strip().replace(" ", "_") or "presentation"
        fname = f"{safe_title}.pptx"

        await msg.answer_document(InputFile(io.BytesIO(pptx_bytes), filename=fname),
                                  caption=f"Muallif: {deck.author_name}")
        USER_STATE.pop(msg.chat.id, None)
        return

if __name__ == "__main__":
    executor.start_polling(dp, skip_updates=True)

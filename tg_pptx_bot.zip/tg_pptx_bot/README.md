# Telegram Presentation Bot (Uzbek) — tg_pptx_bot

Huddi odamdek prezentatsiya yozib, uni `.pptx` ga aylantirib beradigan Telegram bot.

## 📦 Nimalar bor?
- `aiogram` (Telegram bot)
- `OpenAI` LLM chaqiruv (odamdek matn + slaydlar JSON)
- `python-pptx` (slaydlarga aylantirish)
- `pydantic` (LLM JSON-ni tekshirish)
- `Jinja2` (prompt templating)
- `.env` konfiq
- `Dockerfile` (xohlasangiz konteynerda)

## 🚀 Tez start
1) Python 3.11 o'rnating.
2) Repo/fayllarni yuklab oling, keyin:
```bash
pip install -r requirements.txt
cp .env.example .env
# .env ichida TELEGRAM_TOKEN va OPENAI_API_KEY ni to'ldiring
python app/bot.py
```
3) Telegram’da botingizga yozing: `/new`

## 🔑 Tokenlar
- `TELEGRAM_TOKEN` — @BotFather’dan oling.
- `OPENAI_API_KEY` — OpenAI’dan API kalit.

## 🧪 Buyruqlar
- `/start` — salomlashish
- `/new` — yangi taqdimot flow

## ⚙️ Deploy g‘oyalar
- Railway/Render/Fly.io/VPS — polling bilan oson.
- Webhook xohlasa, aiogram webhook rejimi ham qo‘llab-quvvatlaydi (bu MVP polling).

## 🧠 Odamdek ohang
`app/model.py` ichida `SYSTEM_PROMPT` bor — tildagi ohang, slayd soni, struktura, auditoriya
moslashini o'sha yerdan sozlaysiz.
